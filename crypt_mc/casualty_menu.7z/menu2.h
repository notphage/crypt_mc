#pragma once
#include "context.h"

namespace UI
{
	class c_control
	{
	public:
		vec2 m_start;
		vec2 m_bounds;
		vec2 m_end;

		int m_cursor_x;
		int m_cursor_y;
		float m_drag_x;
		float m_drag_y;

		float m_alpha = 255;

		bool m_dragging;
		bool m_should_draw = true;
		bool m_is_inside;

		size_t m_current_tab;

		__forceinline bool is_inside(const float& x, const float& y, const float& w, const float& h)
		{
			return m_cursor_x > x&& m_cursor_x < x + w && m_cursor_y > y&& m_cursor_y < y + h + 1.0f;
		}

		__forceinline bool __is_inside(const float& x, const float& y, const float& w, const float& h)
		{
			return m_cursor_x > x&& m_cursor_x < w && m_cursor_y > y&& m_cursor_y < h + 1.0f;
		}
	};

	class c_window_data
	{
	public:
		int m_draw_counter{};
		int m_draw_counter_open{};
		bool m_first_draw{};

		bool m_first_click{};
		bool m_left_click{};
		bool m_right_click{};
		bool m_ignore{};

		char m_keyboard_input{};

		float m_x{};
		float m_y{};
		float m_fade_speed{};
		color_t m_color = color_t(181, 0, 41, 255);
		int m_alpha = 0;
		int m_last_alpha = 0;
		float m_animation_progress = 0.f;
		bool m_active = true;
	};

	class c_utl_wnd : public c_control
	{
	public:
		static constexpr bool m_should_nigga = ((((((((((((((((((((((bool)((uint32_t)((int)((float)(1)))))))))))))))))))))))));
		bool m_should_draw;
		bool m_should_i_jump_off_a_bridge;

		vec2 m_window_size{};
		vec2* m_pos_setting;
		c_window_data m_data{};
		const float m_edge_size = 8.f;
		bool m_is_inside_edge{};

		void draw_box(float x, float y, float w, float h) const
		{
			// draw black background
			ctx.m_renderer->draw_filled_rect({ x, y, w, h }, color_t(1, 1, 1, m_data.m_alpha));

			// draw grey edge
			ctx.m_renderer->draw_filled_rect({ x + 1.f, y + 1.f, w - 2.f, h - 2.f }, color_t(44, 44, 44, m_data.m_alpha));

			// draw inner box
			ctx.m_renderer->draw_filled_rect({ x + 2.f, y + 2.f, w - 4.f, h - 4.f }, color_t(9, 9, 9, m_data.m_alpha));
		};

	public:
		c_utl_wnd(vec2* pos_setting, float w = 482.f, float h = 550.f)
		{
			m_pos_setting = pos_setting;
			m_window_size = vec2(w, h);
			m_bounds = vec2(w + 20.f, h + 45.f);
			m_end = (*m_pos_setting) + m_bounds;
		}

		__forceinline void resize(const float& w, const float& h) { }

		__forceinline void resize(const vec2& bounds) { }

		__forceinline void resize(const float& h)
		{
			m_window_size.y = h;
			m_bounds.y = h + 45.f;
			m_end = (*m_pos_setting) + m_bounds;
		}

		__forceinline void update_size()
		{
			m_end = (*m_pos_setting) + m_bounds;
		}

		bool handle(const std::string& tab, const bool& setting, const std::function<void(const float&, const float&, const float&, const float&)>& feature = nullptr, const bool& close_with_menu = false)
		{
			m_data.m_draw_counter++;
			m_data.m_keyboard_input = 0; //g_input.g()et_keyboard_input( );

			if (!m_should_i_jump_off_a_bridge)
				m_should_draw = setting;

			if (close_with_menu && setting && !m_should_i_jump_off_a_bridge)
			{
				if (ctx.m_menu_closing)
					m_should_draw = false;

				if (ctx.m_menu_opening)
					m_should_draw = true;
			}

			m_should_i_jump_off_a_bridge = false;

			if (ctx.m_settings.gui_fade_speed > 0)
				m_data.m_alpha = math::clamp<int>(m_should_draw ? (m_data.m_alpha + ctx.m_settings.gui_fade_speed) : (m_data.m_alpha - ctx.m_settings.gui_fade_speed), 0, 255);
			else
				m_data.m_alpha = math::clamp<int>(m_should_draw ? (m_data.m_alpha + 255) : (m_data.m_alpha - 255), 0, 255); // sorry

			m_data.m_color = color_t(ctx.m_settings.gui_accent_color().r(), ctx.m_settings.gui_accent_color().g(), ctx.m_settings.gui_accent_color().b());
			*m_data.m_color.a_ptr() = m_data.m_alpha;

			if (m_data.m_alpha < 0.1f)
			{
				if (close_with_menu && feature)
					feature(m_pos_setting->x + 15.0f, m_pos_setting->y + 40.0f, m_window_size.x, m_window_size.y);

				return false;
			}

			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_is_inside = m_cursor_x > m_pos_setting->x&& m_cursor_x < m_pos_setting->x + m_bounds.x && m_cursor_y > m_pos_setting->y&& m_cursor_y < m_pos_setting->y + m_bounds.y;
			m_is_inside_edge = m_is_inside && ((m_cursor_x > m_pos_setting->x + m_bounds.x - m_edge_size || m_cursor_x < m_pos_setting->x + m_edge_size) || (m_cursor_y > m_pos_setting->y + m_bounds.y - m_edge_size || m_cursor_y < m_pos_setting->y + (30.0f + m_edge_size)));

			// update data
			m_data.m_first_click = !m_data.m_left_click && g_input.is_key_pressed(KEYS_MOUSE1);
			m_data.m_left_click = g_input.is_key_pressed(KEYS_MOUSE1);
			m_data.m_right_click = g_input.is_key_pressed(KEYS_MOUSE2);

			if (!m_data.m_left_click)
				m_data.m_ignore = false;

			if (m_dragging && !m_data.m_left_click)
				m_dragging = false;

			if (m_data.m_first_click && m_is_inside_edge)
			{
				m_dragging = true;
				m_drag_x = m_cursor_x - m_pos_setting->x;
				m_drag_y = m_cursor_y - m_pos_setting->y;
			}

			if (m_dragging)
			{
				m_pos_setting->x = math::clamp(static_cast<float>(m_cursor_x - m_drag_x), 0.0f, static_cast<float>(ctx.m_screen_w) - m_bounds.x);
				m_pos_setting->y = math::clamp(static_cast<float>(m_cursor_y - m_drag_y), 0.0f, static_cast<float>(ctx.m_screen_h) - m_bounds.y);
			}

			m_end = *m_pos_setting + m_bounds;

			// draw black background
			ctx.m_renderer->draw_rect({ m_pos_setting->x, m_pos_setting->y, m_bounds.x, m_bounds.y }, color_t(1, 1, 1, m_data.m_alpha));

			// draw outer light grey box
			ctx.m_renderer->draw_rect({ m_pos_setting->x + 1.f, m_pos_setting->y + 1.f, m_bounds.x - 2.f, m_bounds.y - 2.f }, color_t(57, 57, 57, m_data.m_alpha));

			// draw dark grey box
			ctx.m_renderer->draw_filled_rect({ m_pos_setting->x + 2.f, m_pos_setting->y + 2.f, m_bounds.x - 4.f, m_bounds.y - 4.f }, color_t(35, 35, 35, m_data.m_alpha * 0.5f));

			// draw inner light grey box
			ctx.m_renderer->draw_rect({ m_pos_setting->x + 5.f, m_pos_setting->y + 5.f, m_bounds.x - 10.f, m_bounds.y - 10.f }, color_t(57, 57, 57, m_data.m_alpha));

			// draw main menu background
			ctx.m_renderer->draw_filled_rect({ m_pos_setting->x + 6.f, m_pos_setting->y + 6.f, m_bounds.x - 12.f, m_bounds.y - 12.f }, color_t(4, 4, 4, m_data.m_alpha * 0.5f));

			// draw main box
			draw_box(m_pos_setting->x + 10.f, m_pos_setting->y + 35.f, m_window_size.x, m_window_size.y);

			// tabz
			const color_t tab_color_shadow(0, 0, 0, (m_data.m_alpha / 2) / 2);
			const color_t tab_color_selected = m_data.m_color;

			// spacing per tab
			float tab_spacing = 3.f;

			// total used by spacing
			float spacing = tab_spacing;

			// tab width
			float tab_width = m_window_size.x - spacing;

			float tab_x = m_pos_setting->x + 10.f + (tab_width + tab_spacing) * 0;
			float tab_y = m_pos_setting->y + 25.f;

			ctx.m_renderer->string(ctx.m_renderer->get_font(font_normal), { (tab_x + (tab_width * 0.5f)) + 1.f, (tab_y - 14.f) + 1.f }, tab, color_t(0, 0, 0, m_data.m_alpha));
			ctx.m_renderer->string(ctx.m_renderer->get_font(font_normal), { tab_x + (tab_width * 0.5f), tab_y - 14.f }, tab, color_t(206, 206, 206, m_data.m_alpha));

			ctx.m_renderer->draw_filled_rect({ tab_x, tab_y, tab_width, 4.f }, tab_color_selected);
			ctx.m_renderer->draw_filled_rect({ tab_x, tab_y + 2.f, tab_width, 4.f }, tab_color_shadow);

			// always pass feature, , 
			if (feature)
				feature(m_pos_setting->x + 15.0f, m_pos_setting->y + 40.0f, m_window_size.x, m_window_size.y);

			return true;
		}

		void column_left()
		{
			m_data.m_x = m_pos_setting->x + 50.f;
			m_data.m_y = m_pos_setting->y + 60.f;
		}

		void column_right()
		{
			m_data.m_x = m_pos_setting->x + 280.f;
			m_data.m_y = m_pos_setting->y + 60.f;
		}

		c_window_data* data()
		{
			return &m_data;
		}
	};

	class c_window : public c_control
	{
		bool m_is_open{};
		bool m_was_open{};
		bool m_should_open = true;

		vec2 m_window_size{};
		vec2* m_pos_setting;
		c_window_data m_data{};
		const float m_edge_size = 8.f;
		bool m_is_inside_edge{};

		void draw_watermark(float x, float y, float w, float h)
		{
			const color_t text_shadow(0, 0, 0, m_data.m_alpha);
			const color_t text_color(206, 206, 206, m_data.m_alpha);

			std::string time = xors(__DATE__);
			std::string watermark = time + xors(" | ") + ctx.m_username;

			float text_w = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_normal), watermark).x;

			float text_x = x + w - text_w - 5.f;
			float text_y = y + h - 16.f;

			ctx.m_renderer->string(ctx.m_renderer->get_font(font_normal), { text_x + 1.f, text_y + 1.f }, watermark, text_shadow);
			ctx.m_renderer->string(ctx.m_renderer->get_font(font_normal), { text_x, text_y }, watermark, text_color);
		};

	public:
		//522, 611
		c_window(vec2* pos_setting, float w = 782.f, float h = 414.f)
		{
			// sorry lol
			m_pos_setting = pos_setting;
			m_start = *m_pos_setting;
			m_window_size = vec2(w, h);
			m_bounds = vec2(w + 40.f, h + 60.f);
			m_end = m_start + m_bounds;
		}

		bool handle(std::vector<std::string>& tabs, color_t color)
		{
			ctx.m_block_keyinput = false;

			m_data.m_draw_counter++;
			m_data.m_keyboard_input = g_input.get_keyboard_input();

			if (m_data.m_first_draw)
				m_data.m_first_draw = false;

			if (g_input.is_key_pressed(ctx.m_settings.menu_key().key))
			{
				if (!m_was_open)
					m_should_open = !m_should_open;

				m_was_open = true;
			}
			else
				m_was_open = false;

			// proper frametime
			static auto old = std::chrono::high_resolution_clock::now();
			auto now = std::chrono::high_resolution_clock::now();
			float delta = std::chrono::duration_cast<std::chrono::milliseconds>(now - old).count();

			if (delta >= 31.f)
			{
				old = now;

				if (ctx.m_settings.gui_fade_speed > 0)
					m_data.m_alpha = math::clamp<int>(m_should_open ? (m_data.m_alpha + ctx.m_settings.gui_fade_speed) : (m_data.m_alpha - ctx.m_settings.gui_fade_speed), 0, 255);
				else
					m_data.m_alpha = math::clamp<int>(m_should_open ? (m_data.m_alpha + 255) : (m_data.m_alpha - 255), 0, 255); // sorry

				ctx.m_menu_closing = m_data.m_alpha < 255 && m_data.m_alpha > 1;
				ctx.m_menu_opening = m_should_open && m_data.m_alpha < 255;
				ctx.m_menu_open = m_data.m_alpha == 255 && !ctx.m_menu_closing && !ctx.m_menu_opening;

				m_data.m_color = color;

				*m_data.m_color.a_ptr() = m_data.m_alpha;
			}

			m_is_open = m_data.m_alpha > 0;

			if (!m_is_open)
			{
				m_data.m_draw_counter_open = 0;
				return false;
			}

			if (m_data.m_draw_counter_open == 0)
				m_data.m_first_draw = true;

			m_data.m_draw_counter_open++;

			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_is_inside = m_cursor_x > m_start.x&& m_cursor_x < m_start.x + m_bounds.x && m_cursor_y > m_start.y&& m_cursor_y < m_start.y + m_bounds.y;
			m_is_inside_edge = m_is_inside && ((m_cursor_x > m_start.x + m_bounds.x - m_edge_size || m_cursor_x < m_start.x + m_edge_size) || (m_cursor_y > m_start.y + m_bounds.y - m_edge_size || m_cursor_y < m_start.y + m_edge_size));

			// update data
			m_data.m_first_click = !m_data.m_left_click && g_input.is_key_pressed(KEYS_MOUSE1);
			m_data.m_left_click = g_input.is_key_pressed(KEYS_MOUSE1);
			m_data.m_right_click = g_input.is_key_pressed(KEYS_MOUSE2);
			m_data.m_animation_progress = math::clamp<float>(m_data.m_animation_progress + (ctx.m_frametime * 15.f), 0.f, 1.f);

			if (!m_data.m_left_click)
				m_data.m_ignore = false;

			if (m_dragging && !m_data.m_left_click)
				m_dragging = false;

			if (m_data.m_first_click && m_is_inside_edge)
			{
				m_dragging = true;
				m_drag_x = m_cursor_x - m_start.x;
				m_drag_y = m_cursor_y - m_start.y;
			}

			if (m_dragging)
			{
				m_start.x = math::clamp(static_cast<float>(m_cursor_x - m_drag_x), 0.0f, static_cast<float>(ctx.m_screen_w) - m_bounds.x);
				m_start.y = math::clamp(static_cast<float>(m_cursor_y - m_drag_y), 0.0f, static_cast<float>(ctx.m_screen_h) - m_bounds.y);

				*m_pos_setting = m_start;
			}

			m_end = *m_pos_setting + m_bounds;

			// draw background
			ctx.m_renderer->draw_filled_rect({ m_start.x, m_start.y, m_bounds.x, m_bounds.y }, color_t(23, 30, 41, m_data.m_alpha));

			// tab bar
			vec2 tab_accent_size(300, 40);
			vertex_t tab_bar[] =
			{
				{ m_start.x,						    m_start.y,					   color_t(197, 46, 130, m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x,	    m_start.y,					   color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x,						    m_start.y + tab_accent_size.y, color_t(200, 45, 128, m_data.m_alpha) },
										 
				{ m_start.x + tab_accent_size.x,		m_start.y,					   color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x - 40.f, m_start.y + tab_accent_size.y, color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x,							m_start.y + tab_accent_size.y, color_t(200, 45, 128, m_data.m_alpha) }
			};
			
			ctx.m_renderer->add_vertices(tab_bar, 0x0004 /* GL_TRIANGLES */);

			vertex_t tab_bar_accent[] =
			{
				{ m_start.x + tab_accent_size.x - 15.f,	m_start.y,					   color_t(197, 46, 130, m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x,	    m_start.y,					   color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x - 55.f, m_start.y + tab_accent_size.y, color_t(200, 45, 128, m_data.m_alpha) },

				{ m_start.x + tab_accent_size.x,		m_start.y,					   color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x - 40.f, m_start.y + tab_accent_size.y, color_t(238, 39, 98,  m_data.m_alpha) },
				{ m_start.x + tab_accent_size.x - 55.f,	m_start.y + tab_accent_size.y, color_t(200, 45, 128, m_data.m_alpha) }
			};

			ctx.m_renderer->add_vertices(tab_bar_accent, 0x0004 /* GL_TRIANGLES */);

			ctx.m_renderer->string(ctx.m_renderer->get_font(font_fury_title_serif), { m_start.x + tab_accent_size.x - 59.f, m_start.y + (tab_accent_size.y * 0.5f) - 1.f }, xors("CASUALTY"), { 255, 255, 255, m_data.m_alpha }, TEXT_RIGHT);

			// tabs
			const color_t text_color_shadow(0, 0, 0, m_data.m_alpha);

			vec2 tab_bar_start(m_start.x + tab_accent_size.x, m_start.y);
			vec2 tab_bar_bounds(m_bounds.x - tab_accent_size.x, tab_accent_size.y);
			vec2 tab_bar_end = tab_bar_start + tab_bar_bounds;

			float tab_spacing = 3.f;
			float tab_width = (tab_bar_bounds.x - (tabs.size() * tab_spacing)) / tabs.size();

			for (size_t i = 0; i < tabs.size(); i++)
			{
				color_t text_color(255, 255, 255, m_data.m_alpha);

				float tab_x = tab_bar_start.x + (tab_width + tab_spacing) * i;
				float tab_y = tab_bar_start.y + 7.f;
				vec2 tab_bounds(tab_width, tab_bar_bounds.y - 14.f);

				if (is_inside(tab_x, tab_y, tab_bounds.x, tab_bounds.y) && m_current_tab != i)
				{
					//select it if we are inside it and pressing
					if (m_data.m_first_click)
					{
						m_current_tab = i;
						m_data.m_animation_progress = 0.f;
					}
					else
					{
						text_color = color_t(230, 230, 230, m_data.m_alpha);
						ctx.m_renderer->draw_filled_rect({ tab_x, tab_bar_end.y - 2.f, tab_bounds.x, 2.f }, { 125, 201, 197, (int)(m_data.m_alpha * 0.7f) });
					}
				}

				if (m_current_tab == i)
					ctx.m_renderer->draw_filled_rect({ tab_x, tab_bar_end.y - 2.f, tab_bounds.x, 2.f }, { 125, 201, 197, m_data.m_alpha });

				vec2 text_bounds = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_header_serif), tabs.at(i));
				float text_x = tab_x + (tab_bounds.x * 0.5f);
				float text_y = tab_y + (tab_bounds.y * 0.5f) - 4.f;

				ctx.m_renderer->string(ctx.m_renderer->get_font(font_fury_header_serif), { text_x + 1.f, text_y + 1.f }, tabs.at(i), text_color_shadow, TEXT_CENTER);
				ctx.m_renderer->string(ctx.m_renderer->get_font(font_fury_header_serif), { text_x, text_y }, tabs.at(i), text_color, TEXT_CENTER);
			}

			return true;
		}

		void column_left()
		{
			float column_width = (m_bounds.x - 60.f) / 3.f;
			m_data.m_x = m_start.x + 52.f;
			m_data.m_y = m_start.y + 50.f;
		}

		void column_center()
		{
			float column_width = (m_bounds.x - 60.f) / 3.f;
			m_data.m_x = m_start.x + 52.f + column_width;
			m_data.m_y = m_start.y + 50.f;
		}

		void column_right()
		{
			float column_width = (m_bounds.x - 60.f) / 3.f;
			m_data.m_x = m_start.x + 52.f + (column_width * 2.f);
			m_data.m_y = m_start.y + 50.f;
		}

		c_window_data* data()
		{
			return &m_data;
		}
	};

	class c_groupbox : public c_control
	{
		static constexpr size_t m_text_length = 32;

		char m_text[m_text_length]{};

	public:
		void start(c_window_data* data, const char* text)
		{
			strncpy_s(m_text, m_text_length, text, m_text_length);
			m_start = vec2(data->m_x - 10.f, data->m_y + 5.f);

			// setup coord for next item
			data->m_y += 41.f;
		}

		void end(c_window_data* data)
		{
			m_end = vec2(data->m_x - 10.f, data->m_y + 5.f);

			// setup coord for next item
			data->m_y += 15.f;

			draw(data);
		}

		void draw(c_window_data* data)
		{
			const color_t text_color(206, 206, 206, data->m_alpha);
			const color_t rect_color(31, 43, 59, data->m_alpha);
			const color_t edge_color(49, 67, 93, data->m_alpha);

			float width = 230.f;

			vec2 text_bounds = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_normal), m_text);

			ctx.m_renderer->draw_filled_rounded_rect({ m_start.x, m_start.y, width, m_end.y - m_start.y }, rect_color);
			ctx.m_renderer->draw_rounded_rect({ m_start.x, m_start.y, width, m_end.y - m_start.y }, edge_color);

			if (strlen(m_text) > 0)
			{
				ctx.m_renderer->string(ctx.m_renderer->get_font(font_fury_header_serif), { m_start.x + (width / 2.f), m_start.y + 6.f }, m_text, text_color, TEXT_CENTER);
				ctx.m_renderer->draw_rect({ m_start.x, m_start.y + 24.f, width, 1.f }, edge_color, 0.5f); // stupid hack because of opengl wanting to draw a 2 height line >:(

				// dont leave it around in memory unencrypted
				memset(m_text, 0, m_text_length);
			}
		}
	};

	class c_checkbox : public c_control
	{
		const char* m_text{};
		bool* m_value{};
	public:
		c_checkbox()
		{
			m_bounds = vec2(10, 10);
		}

		void draw(c_window_data* data)
		{
			const color_t text_color(206, 206, 206, data->m_alpha);
			const color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 21.f, m_start.y - 1.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 20.f, m_start.y }, m_text, text_color);
			}

			// inner box empty
			ctx.m_renderer->draw_rect(ctx.m_renderer->m_menu_element_list, { m_start.x, m_start.y, m_bounds.x, m_bounds.y }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_start.x, m_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			// inner box
			if (*m_value)
				ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_start.x + 1.f, m_start.y + 1.f, m_bounds.x - 2.f, m_bounds.y - 2.f }, data->m_color);
		}

		void handle(c_window_data* data, const char* name, bool* setting)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = name;
			m_value = setting;

			m_start = vec2(data->m_x, data->m_y);
			m_end = m_start + m_bounds;

			// setup coord for next item
			data->m_y += 20.f;

			float text_width = m_text ? ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), m_text).x : 0.f;

			m_is_inside = m_cursor_x > m_start.x&& m_cursor_x < m_start.x + 20.f + text_width + 5.f && m_cursor_y > m_start.y - 3.f && m_cursor_y < m_end.y + 3.f;

			if (m_value && data->m_left_click && !data->m_ignore && m_is_inside)
			{
				*m_value = !*m_value;
				data->m_ignore = true;
			}

			draw(data);
		}
	};


	class c_slider : public c_control
	{
		int* m_value;
		int m_min;
		int m_max;
		int m_step;

		const char* m_text;
		const char* m_suffix;

		vec2 m_slider_start;
		float m_slider_pos;

		float m_slider_width;
		float m_slider_height;

		vec2 m_minus_pos;
		vec2 m_minus_bounds;

		vec2 m_plus_pos;
		vec2 m_plus_bounds;

	public:
		c_slider()
		{
			m_slider_width = 170.f;
			m_slider_height = 8.f;

			m_bounds = vec2(m_slider_width, m_slider_height);

			m_minus_bounds = vec2(12.f, 12.f);
			m_plus_bounds = vec2(12.f, 12.f);
		}

	public:
		void draw(c_window_data* data)
		{
			color_t text_color(206, 206, 206, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 21.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 20.f, m_start.y - 3.f }, m_text, text_color);
			}

			text_color = { 255, 255, 255, data->m_alpha };

			// inner background
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x - 1.f, m_slider_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x, m_slider_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			// slider bar
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x, m_slider_start.y, m_slider_pos, m_bounds.y }, data->m_color);

			// plus/minus
			if (m_min != *m_value)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_minus_pos.x + (m_minus_bounds.x * 0.5f) - 1.f, m_minus_pos.y + 2.f - (m_minus_bounds.y * 0.5f) + 1.f }, xors("-"), text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_minus_pos.x + (m_minus_bounds.x * 0.5f) - 2.f, m_minus_pos.y + 2.f - (m_minus_bounds.y * 0.5f) + 2.f }, xors("-"), text_color);
			}

			if (m_max != *m_value)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_plus_pos.x + (m_plus_bounds.x * 0.5f) - 3.f, m_plus_pos.y + 2.f - (m_plus_bounds.y * 0.5f) + 1.f }, xors("+"), text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_plus_pos.x + (m_plus_bounds.x * 0.5f) - 4.f, m_plus_pos.y + 2.f - (m_plus_bounds.y * 0.5f) + 2.f }, xors("+"), text_color);
			}

			char buf[1024];
			sprintf(buf, xors("%i%s"), *m_value, m_suffix);

			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_slider_start.x + m_slider_pos + 1.f, m_slider_start.y + 10.f }, buf, text_shadow, TEXT_CENTER);
			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_slider_start.x + m_slider_pos, m_slider_start.y + 11.f }, buf, text_color, TEXT_CENTER);

			for (int i = 0; i < sizeof(buf); i++)
				buf[i] = '\0';
		}

		void handle(c_window_data* data, const char* name, int* setting, int min, int max, int step = 1, std::string suffix = "")
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = strlen(name) > 1 ? name : nullptr;
			m_min = min;
			m_max = max;
			m_step = step;

			m_value = setting;

			// ? like character from some spic language			// xor bug
			if (suffix[0] == 0xc2)
			{
				// get rid of that pesky lil guy
				m_suffix = suffix.erase(0, 1).c_str();
			}
			else
			{
				// normal suffix nothing to see here
				m_suffix = suffix.c_str() ? suffix.c_str() : "";
			}

			m_start = vec2(data->m_x, data->m_y);
			m_slider_start = vec2(m_start.x + 20.f, m_start.y);
			m_end = m_slider_start + m_bounds;

			m_minus_pos = m_slider_start;
			m_minus_pos.x -= m_minus_bounds.x + 10.f;

			m_plus_pos = m_slider_start;
			m_plus_pos.x += m_slider_width + 10.f;

			data->m_y += 25.f;

			if (m_text)
			{
				m_slider_start.y += 15.f;
				m_minus_pos.y += 15.f;
				m_plus_pos.y += 15.f;

				m_end.y += 15.f;
				data->m_y += 20.f;
			}

			m_is_inside = m_cursor_x > m_slider_start.x - 1.0f && m_cursor_x < m_end.x + 1.0f && m_cursor_y > m_slider_start.y - 1.0f && m_cursor_y < m_end.y + 1.0f;

			if (m_dragging && !data->m_left_click)
				m_dragging = false;

			if (m_value)
			{
				*m_value = math::clamp<int>(*m_value, m_min, m_max);

				if (m_dragging)
				{
					float dragged_pos = math::clamp<float>(m_cursor_x - m_slider_start.x, 0, m_slider_width);
					*m_value = m_min + ((m_max - m_min) * dragged_pos / m_slider_width);
				}

				if (data->m_first_click && !data->m_ignore)
				{
					if (m_is_inside)
					{
						m_dragging = true;
						data->m_ignore = true;
					}
					else if (m_cursor_y > m_minus_pos.y&& m_cursor_y < (m_minus_pos.y + m_minus_bounds.y))
					{
						if (m_cursor_x > m_minus_pos.x&& m_cursor_x < (m_minus_pos.x + m_minus_bounds.x))
						{
							*m_value = math::clamp<int>(*m_value - m_step, m_min, m_max);
							data->m_ignore = true;
						}
						else if (m_cursor_x > m_plus_pos.x&& m_cursor_x < (m_plus_pos.x + m_plus_bounds.x))
						{
							*m_value = math::clamp<int>(*m_value + m_step, m_min, m_max);
							data->m_ignore = true;
						}
					}
				}

				m_slider_pos = (float(*m_value - m_min) / float(m_max - m_min) * m_slider_width);
				m_slider_pos = math::clamp<float>(m_slider_pos, 0.f, m_slider_width * data->m_animation_progress);
			}

			draw(data);
		}
	};


	class c_float_slider : public c_control
	{
		float* m_value;
		float m_min;
		float m_max;
		float m_step;

		const char* m_text;
		const char* m_suffix;
		const char* m_formatting;

		vec2 m_slider_start;
		float m_slider_pos;

		float m_slider_width;
		float m_slider_height;

		vec2 m_minus_pos;
		vec2 m_minus_bounds;

		vec2 m_plus_pos;
		vec2 m_plus_bounds;

	public:
		c_float_slider()
		{
			m_slider_width = 170.f;
			m_slider_height = 8.f;

			m_bounds = vec2(m_slider_width, m_slider_height);

			m_minus_bounds = vec2(10.f, 10.f);
			m_plus_bounds = vec2(10.f, 10.f);
		}

	public:
		void draw(c_window_data* data)
		{
			color_t text_color(206, 206, 206, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 21.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 20.f, m_start.y - 3.f }, m_text, text_color);
			}

			text_color = { 255, 255, 255, data->m_alpha };

			// inner background
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x - 1.f, m_slider_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x, m_slider_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			// slider bar
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_slider_start.x, m_slider_start.y, m_slider_pos, m_bounds.y }, data->m_color);

			// plus/minus
			if (m_min != *m_value)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_minus_pos.x + (m_minus_bounds.x * 0.5f) - 1.f, m_minus_pos.y + 2.f - (m_minus_bounds.y * 0.5f) }, xors("-"), text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_minus_pos.x + (m_minus_bounds.x * 0.5f) - 2.f, m_minus_pos.y + 2.f - (m_minus_bounds.y * 0.5f) + 1.f }, xors("-"), text_color);
			}

			if (m_max != *m_value)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_plus_pos.x + (m_plus_bounds.x * 0.5f) - 3.f, m_plus_pos.y + 2.f - (m_plus_bounds.y * 0.5f) + 1.f }, xors("+"), text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_plus_pos.x + (m_plus_bounds.x * 0.5f) - 4.f, m_plus_pos.y + 2.f - (m_plus_bounds.y * 0.5f) + 2.f }, xors("+"), text_color);
			}

			char buf[1024];
			sprintf(buf, xors("%.2f%s"), *m_value, m_suffix);

			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_slider_start.x + m_slider_pos + 1.f, m_slider_start.y + 10.f }, buf, text_shadow, TEXT_CENTER);
			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_slider_start.x + m_slider_pos, m_slider_start.y + 11.f }, buf, text_color, TEXT_CENTER);

			for (int i = 0; i < sizeof(buf); i++)
				buf[i] = '\0';
		}

		void handle(c_window_data* data, const char* name, float* setting, float min, float max, float step = 1.f, std::string formatting = xors("%.2f"), std::string suffix = "")
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = strlen(name) > 1 ? name : nullptr;
			m_min = min;
			m_max = max;
			m_step = step;

			m_value = setting;

			// ? like character from some spic language			// xor bug
			if (suffix[0] == 194)
			{
				// get rid of that pesky lil guy
				m_suffix = suffix.erase(0, 1).c_str();
			}
			else
			{
				// normal suffix nothing to see here
				m_suffix = suffix.c_str() ? suffix.c_str() : "";
			}

			// ? like character from some spic language			// xor bug
			if (formatting[0] == 194)
			{
				// get rid of that pesky lil guy
				m_formatting = formatting.erase(0, 1).c_str();
			}
			else
			{
				// normal suffix nothing to see here
				m_formatting = formatting.c_str() ? formatting.c_str() : "";
			}

			m_start = vec2(data->m_x, data->m_y);
			m_slider_start = vec2(m_start.x + 20.f, m_start.y);
			m_end = m_slider_start + m_bounds;

			m_minus_pos = m_slider_start;
			m_minus_pos.x -= m_minus_bounds.x + 10.f;

			m_plus_pos = m_slider_start;
			m_plus_pos.x += m_slider_width + 10.f;

			data->m_y += 25.f;

			if (m_text)
			{
				m_slider_start.y += 15.f;
				m_minus_pos.y += 15.f;
				m_plus_pos.y += 15.f;

				m_end.y += 15.f;
				data->m_y += 20.f;
			}

			m_is_inside = m_cursor_x > m_slider_start.x - 1.0f && m_cursor_x < m_end.x + 1.0f && m_cursor_y > m_slider_start.y - 1.0f && m_cursor_y < m_end.y + 1.0f;

			if (m_dragging && !data->m_left_click)
				m_dragging = false;

			if (m_value)
			{
				*m_value = math::clamp<float>(*m_value, m_min, m_max);

				if (m_dragging)
				{
					float dragged_pos = math::clamp<float>(m_cursor_x - m_slider_start.x, 0, m_slider_width);
					*m_value = m_min + ((m_max - m_min) * dragged_pos / m_slider_width);
				}

				if (data->m_first_click && !data->m_ignore)
				{
					if (m_is_inside)
					{
						m_dragging = true;
						data->m_ignore = true;
					}
					else if (m_cursor_y > m_minus_pos.y&& m_cursor_y < (m_minus_pos.y + m_minus_bounds.y))
					{
						if (m_cursor_x > m_minus_pos.x&& m_cursor_x < (m_minus_pos.x + m_minus_bounds.x))
						{
							*m_value = math::clamp<float>(*m_value - m_step, m_min, m_max);
							data->m_ignore = true;
						}
						else if (m_cursor_x > m_plus_pos.x&& m_cursor_x < (m_plus_pos.x + m_plus_bounds.x))
						{
							*m_value = math::clamp<float>(*m_value + m_step, m_min, m_max);
							data->m_ignore = true;
						}
					}
				}

				m_slider_pos = ((*m_value - m_min) / (m_max - m_min) * m_slider_width);
				m_slider_pos = math::clamp<float>(m_slider_pos, 0.f, m_slider_width * data->m_animation_progress);
			}

			draw(data);
		}
	};

	class c_button : public c_control
	{
		const char* m_text{};
	public:
		void draw(c_window_data* data)
		{
			color_t color = color_t(18, 23, 32, data->m_alpha);

			if (m_is_inside && data->m_left_click)
				color = color_t(39, 50, 69, data->m_alpha);

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_start.x - 1.f, m_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_start.x, m_start.y, m_bounds.x, m_bounds.y }, color);

			auto text_color = m_is_inside && data->m_left_click ? data->m_color : color_t(255, 255, 255, data->m_alpha);
			if (m_text)
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { (m_start.x + (m_bounds.x * 0.5f)), m_start.y + (m_bounds.y * 0.5f) - 6.f }, m_text, text_color, TEXT_CENTER);
		}

		void handle(c_window_data* data, const char* text, const std::function<void()>& function)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = text;
			m_start = vec2(data->m_x + 20.f, data->m_y);
			m_bounds = vec2(150.f, 20.f);
			m_end = m_start + m_bounds;

			data->m_y += 30.f;

			m_is_inside = m_cursor_x > m_start.x&& m_cursor_x < m_end.x && m_cursor_y > m_start.y&& m_cursor_y < m_end.y;

			if (data->m_left_click && !data->m_ignore && m_is_inside)
			{
				function();
				data->m_ignore = true;
			}

			draw(data);
		}
	};

	class c_key_bind : public c_control
	{
		int m_key_type = kt_hold;
		bool m_type_dropdown = false;
		int m_draw_tick{};

		const char* m_text{};
		keysetting_t* m_key{};
		std::vector<std::string> m_items = { xors("hold"), xors("toggle"), xors("always on"), "" };
		const float m_item_height = 16;

		vec2 m_box_start, m_box_end;
		bool m_is_waiting{};

		bool m_is_inside_items{};
		float m_dropdown_end{};

		keytype_t m_type{};
	public:
		void handle(c_window_data* data, const char* text, keysetting_t* key, keytype_t type = kt_all)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = strlen(text) > 1 ? text : nullptr;
			m_key = key;
			m_draw_tick = data->m_draw_counter;
			m_type = type;

			m_start = vec2(data->m_x + 20.f, data->m_y);
			m_box_start = vec2(m_start.x, m_start.y);

			data->m_y += 30.f;

			if (m_text)
			{
				m_box_start.y += 15.f;
				data->m_y += 20.f;
			}

			m_bounds = vec2(150, 20);

			m_end = m_box_start + m_bounds;

			m_box_end = m_end;

			if (m_type_dropdown)
			{
				const float h = 3 * 16;
				m_box_end.y += h + 3.f;
			}

			m_is_inside = m_cursor_x > m_box_start.x&& m_cursor_x < m_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_end.y;
			m_is_inside_items = m_cursor_x > m_box_start.x&& m_cursor_x < m_box_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_box_end.y;

			if (data->m_left_click && m_is_inside && !data->m_ignore)
			{
				m_is_waiting = true;
				data->m_ignore = true;
			}

			if (m_is_waiting && m_key->type == kt_always)
			{
				data->m_ignore = false;
				m_is_waiting = false;
			}

			static bool clicked = false;
			if (data->m_active)
			{
				if (m_is_inside && data->m_right_click && !clicked)
				{
					m_type_dropdown = !m_type_dropdown;
					clicked = true;
				}

				if (!m_is_inside && m_type_dropdown && m_is_inside_items && data->m_left_click)
				{
					float offset = m_cursor_y - m_end.y;
					m_key->type = (int)(offset / m_item_height);
					clicked = false;

					m_type_dropdown = false;
				}
				else if (!m_is_inside && !m_is_inside_items && data->m_left_click)
				{
					m_type_dropdown = false;
					clicked = false;
				}

				if (!data->m_right_click && clicked)
					clicked = false;

				if (m_type != kt_all)
				{
					m_type_dropdown = false;
					m_key->type = m_type;
				}
			}

			if (m_type_dropdown)
			{
				data->m_ignore = true;
				m_is_waiting = false;
			}

			if (m_is_waiting)
				ctx.m_block_keyinput = true;

			if (m_is_waiting)
			{
				VirtualKeys_t start_key = data->m_ignore ? KEYS_MOUSE1 : KEYS_NONE;

				if (g_input.is_any_key_pressed() == KEYS_ESCAPE)
				{
					m_is_waiting = false;
					m_key->key = KEYS_NONE;
				}
				else if (g_input.is_any_key_pressed() > start_key)
				{
					m_key->key = (g_input.is_any_key_pressed() == KEYS_MOUSE1 || g_input.is_any_key_pressed() == KEYS_MOUSE2) ? KEYS_NONE : g_input.is_any_key_pressed();
					m_is_waiting = false;
					data->m_ignore = true;
				}
			}

			draw(data);
		}

		void draw(c_window_data* data)
		{
			color_t text_color(255, 255, 255, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 1.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x, m_start.y - 3.f }, m_text, text_color);
			}

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_box_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_box_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			if (m_is_waiting && !m_key->key)
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.0f, m_box_start.y + 3.f }, xors("press key"), data->m_color);

			if (m_key->key > KEYS_NONE || m_key->type == kt_always)
			{
				if (m_key->key > KEYS_NONE)
				{
					const auto key_name = g_input.get_key_name((VirtualKeys_t)m_key->key);

					int alpha = m_is_waiting ? data->m_color.a() : data->m_alpha;

					if (m_key->type == kt_always)
						alpha = 100;

					if (!m_is_waiting)
						ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.0f, m_box_start.y + 3.f }, key_name, color_t(255, 255, 255, alpha));
					else
						ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.0f, m_box_start.y + 3.f }, key_name, color_t(data->m_color.r(), data->m_color.g(), data->m_color.b(), alpha));
				}

				text_color = !m_type_dropdown ? color_t(255, 255, 255, data->m_alpha) : data->m_color;

				if (m_key->key <= KEYS_NONE && m_key->type == kt_always)
					ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.0f, m_box_start.y + 3.f }, m_items[m_key->type], text_color);
				else
				{
					auto buffer_width = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), m_items[m_key->type]).x;
					ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_end.x - (buffer_width + 10.0f), m_box_start.y + 3.f }, m_items[m_key->type], text_color);
				}
			}
		}

		void dropdown(c_window_data* data)
		{
			if (m_draw_tick != data->m_draw_counter)
				return;

			if (data->m_alpha < 255)
			{
				m_type_dropdown = false;
				m_dropdown_end = 0.f;
			}

			if (m_type_dropdown)
			{
				m_dropdown_end += 3.f;

				if (m_dropdown_end + m_end.y > m_box_end.y)
					m_dropdown_end = m_box_end.y - m_end.y;
			}
			else
			{
				m_dropdown_end -= 3.f;

				if (m_dropdown_end <= 0.f)
					m_dropdown_end = 0.f;
			}

			// shop is closed!
			if (m_dropdown_end <= 0.f)
				return;

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_end.y + 2.f, (m_box_end.x + 2.f) - m_box_start.x, m_bounds.y + m_dropdown_end - 21.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_end.y + 3.f, (m_box_end.x) - m_box_start.x, m_bounds.y + m_dropdown_end - 23.f }, color_t(18, 23, 32, data->m_alpha));

			for (size_t i = 0; i < m_items.size(); i++)
			{
				float x = m_box_start.x + 10.f;
				float y = m_end.y + 5.f + i * 16.f;

				if (y + (m_item_height * 0.5f) > m_end.y + m_dropdown_end - 2.f)
					continue;

				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { x, y }, m_items[i], m_key->type == i ? data->m_color : color_t(255, 255, 255, data->m_alpha));
			}
		}
	};

	struct dropdown_item_t2
	{
		std::string item;
		color_t color = color_t(153, 153, 153);
	};

	class c_dropdown : public c_control
	{
		const char* m_text{};
		std::vector<std::string> m_items{};

		int* m_setting{};
		bool m_is_open{};
		int m_draw_tick{};

		vec2 m_box_start;
		vec2 m_box_end;
		bool m_is_inside_items{};
		float m_dropdown_end{};

		int m_item_offset{};
		int m_max_items{};

		const float m_item_height = 16.f;
	public:

		void handle(c_window_data* data, const char* text, const std::vector<std::string>& items, int* setting, int max_items = 0, const bool& disabled = false, std::string* out = nullptr)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			data->m_active = disabled == false;

			m_text = strlen(text) > 1 ? text : nullptr;
			m_items = items;
			m_setting = setting;
			m_draw_tick = data->m_draw_counter;
			m_max_items = max_items < items.size() ? max_items : 0;

			if (disabled)
				m_is_open = false;

			// handle scroll and set m_item_offset
			if (m_is_open && m_max_items)
			{
				int scroll_input = g_input.get_scroll_state();

				/*if ( g_input.is_key_pressed( KEYS_DOWN ) )
					scroll_input = -1;
				else if ( g_input.is_key_pressed( KEYS_UP ) )
					scroll_input = 1;*/

				m_item_offset = math::clamp<int>(m_item_offset - scroll_input, 0, items.size() - m_max_items);
			}
			else
			{
				m_item_offset = 0;
			}

			m_start = vec2(data->m_x + 20.f, data->m_y);
			m_box_start = vec2(m_start.x, m_start.y);

			data->m_y += 30.f;

			if (m_text)
			{
				m_box_start.y += 15.f;
				data->m_y += 20.f;
			}

			m_bounds = vec2(150, 20);

			m_end = m_box_start + m_bounds;

			m_box_end = m_end;

			if (m_is_open)
			{
				float h = m_max_items ? m_max_items * m_item_height : items.size() * m_item_height;
				m_box_end.y += h + 3.f;
			}

			m_is_inside = m_cursor_x > m_box_start.x&& m_cursor_x < m_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_end.y;
			m_is_inside_items = m_cursor_x > m_box_start.x&& m_cursor_x < m_box_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_box_end.y;

			if (data->m_active && data->m_left_click && !data->m_ignore)
			{
				if (m_is_inside)
				{
					m_is_open = !m_is_open;
					data->m_ignore = true;
				}
				else if (m_is_open && m_is_inside_items)
				{
					float offset = m_cursor_y - m_end.y;
					*m_setting = m_item_offset + (int)(offset / m_item_height);
					data->m_ignore = true;

					m_is_open = false;
				}
				else
				{
					m_is_open = false;
				}
			}

			//clamp setting to avoid cwashing
			*m_setting = math::clamp<int>(*m_setting, 0, math::max<int>(0, items.size() - 1));

			if (out)
				*out = m_items[*m_setting];

			draw(data);
		}

		void draw(c_window_data* data)
		{
			color_t text_color(255, 255, 255, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 1.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x, m_start.y - 3.f }, m_text, text_color);
			}

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_box_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_box_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			text_color = data->m_active ? color_t(255, 255, 255, data->m_alpha) : color_t(153, 153, 153, data->m_alpha);
			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.f, m_box_start.y + 3.f }, m_items.at(*m_setting), text_color);

			// bester arrow
			const color_t arrow_color(255, 255, 255, data->m_alpha);

			float x = m_end.x - 11.f;
			float y = m_box_start.y + 9.f;

			if (m_is_open)
			{
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 2.f, y }, { x + 3.f, y }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 1.f, y + 1.f }, { x + 4.f, y + 1.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x, y + 2.f }, { x + 5.f, y + 2.f }, arrow_color);
			}
			else
			{
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 2.f, y + 2.f }, { x + 3.f, y + 2.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 1.f, y + 1.f }, { x + 4.f, y + 1.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x, y }, { x + 5.f, y }, arrow_color);
			}
		}

		void dropdown(c_window_data* data)
		{
			if (m_draw_tick != data->m_draw_counter)
				return;

			if (data->m_alpha < 255)
			{
				m_is_open = false;
				m_dropdown_end = 0.f;
			}

			if (m_is_open)
			{
				m_dropdown_end += 3.f;

				if (m_dropdown_end + m_end.y > m_box_end.y)
					m_dropdown_end = m_box_end.y - m_end.y;
			}
			else
			{
				m_dropdown_end -= 3.f;

				if (m_dropdown_end <= 0.f)
					m_dropdown_end = 0.f;
			}

			// shop is closed!
			if (m_dropdown_end <= 0.f)
				return;

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_end.y + 2.f, (m_box_end.x + 2.f) - m_box_start.x, m_bounds.y + m_dropdown_end - 21.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_end.y + 3.f, (m_box_end.x) - m_box_start.x, m_bounds.y + m_dropdown_end - 23.f }, color_t(18, 23, 32, data->m_alpha));

			size_t start = m_max_items ? m_item_offset : 0;
			size_t count = m_max_items ? m_max_items : m_items.size();

			for (size_t i = 0; i < count; i++)
			{
				float x = m_box_start.x + 10.f;
				float y = m_end.y + 5.f + i * m_item_height;

				if (y + (m_item_height * 0.5f) > m_end.y + m_dropdown_end - 2.f)
					continue;

				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { x, y }, m_items.at(start + i), *m_setting == start + i ? data->m_color : color_t(255, 255, 255, data->m_alpha));
			}

			// draw scrollbar
			if (m_is_open && m_max_items && m_max_items < m_items.size())
			{
				float fraction = float(m_max_items) / float(m_items.size());

				float length = m_dropdown_end - 2.f;
				float scroll_size = fraction * length;
				float scroll_step = length / float(m_items.size());

				float scroll_start = scroll_step * m_item_offset;

				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { m_box_end.x - 3.f, m_end.y + 4.f + scroll_start + 1.f }, { m_box_end.x - 3.f, m_end.y + 2.f + scroll_start + scroll_size - 1.f }, data->m_color);
			}
		}
	};

	struct dropdown_item_t
	{
		bool* m_setting;
		std::string m_text;
	};

	class c_multi_dropdown : public c_control
	{
		const char* m_text{};
		std::vector<dropdown_item_t> m_items{};

		bool m_is_open{};
		int m_draw_tick{};

		vec2 m_box_start;
		vec2 m_box_end;
		bool m_is_inside_items{};
		float m_dropdown_end{};

		const float m_item_height = 16.f;
	public:

		void handle(c_window_data* data, const char* text, const std::vector<dropdown_item_t>& items)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = strlen(text) > 1 ? text : nullptr;
			m_items = items;
			m_draw_tick = data->m_draw_counter;

			m_start = vec2(data->m_x + 20.f, data->m_y);
			m_box_start = vec2(m_start.x, m_start.y);

			items.at(0);

			data->m_y += 30.f;

			if (m_text)
			{
				m_box_start.y += 15.f;
				data->m_y += 20.f;
			}

			m_bounds = vec2(150, 20);

			m_end = m_box_start + m_bounds;

			m_box_end = m_end;

			if (m_is_open)
			{
				float h = items.size() * m_item_height;
				m_box_end.y += h + 3.f;
			}

			m_is_inside = m_cursor_x > m_box_start.x&& m_cursor_x < m_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_end.y;
			m_is_inside_items = m_cursor_x > m_box_start.x&& m_cursor_x < m_box_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_box_end.y;

			if (data->m_left_click && !data->m_ignore)
			{
				if (m_is_inside)
				{
					m_is_open = !m_is_open;
					data->m_ignore = true;
				}
				else if (m_is_open && m_is_inside_items)
				{
					float offset = m_cursor_y - m_end.y;
					int clicked_item = math::clamp<int>((int)(offset / m_item_height), 0, math::max<int>(0, m_items.size() - 1));
					*m_items.at(clicked_item).m_setting = !*m_items.at(clicked_item).m_setting;
					data->m_ignore = true;
				}
				else
				{
					m_is_open = false;
				}
			}

			draw(data);
		}

		void draw(c_window_data* data)
		{
			color_t text_color(255, 255, 255, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 1.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x, m_start.y - 3.f }, m_text, text_color);
			}

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_box_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_box_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			std::string items_text;
			if (!m_items.empty())
			{
				for (size_t i = 0; i < m_items.size(); i++)
				{
					if (!*m_items.at(i).m_setting)
						continue;

					const float width_limit = 120.f;

					float new_width = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), items_text + m_items.at(i).m_text).x;

					if (new_width > width_limit)
					{
						items_text += xors(", ...");
						break;
					}

					if (!items_text.empty())
						items_text += ", ";

					items_text += m_items.at(i).m_text;
				}
			}
			else
			{
				items_text = "-";
			}

			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.f, m_box_start.y + 3.f }, items_text, color_t(255, 255, 255, data->m_alpha));

			// bester arrow
			const color_t arrow_color(255, 255, 255, data->m_alpha);

			float x = m_end.x - 11.f;
			float y = m_box_start.y + 9.f;

			if (m_is_open)
			{
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 2.f, y }, { x + 3.f, y }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 1.f, y + 1.f }, { x + 4.f, y + 1.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x, y + 2.f }, { x + 5.f, y + 2.f }, arrow_color);
			}
			else
			{
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 2.f, y + 2.f }, { x + 3.f, y + 2.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x + 1.f, y + 1.f }, { x + 4.f, y + 1.f }, arrow_color);
				ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { x, y }, { x + 5.f, y }, arrow_color);
			}
		}

		void dropdown(c_window_data* data)
		{
			if (m_draw_tick != data->m_draw_counter)
				return;

			if (data->m_alpha < 255)
			{
				m_is_open = false;
				m_dropdown_end = 0.f;
			}

			if (m_is_open)
			{
				m_dropdown_end += 3.f;

				if (m_dropdown_end + m_end.y > m_box_end.y)
					m_dropdown_end = m_box_end.y - m_end.y;
			}
			else
			{
				m_dropdown_end -= 3.f;

				if (m_dropdown_end <= 0.f)
					m_dropdown_end = 0.f;
			}

			// shop is closed!
			if (m_dropdown_end <= 0.f)
				return;

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_end.y + 2.f, (m_box_end.x + 2.f) - m_box_start.x, m_bounds.y + m_dropdown_end - 21.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_end.y + 3.f, (m_box_end.x) - m_box_start.x, m_bounds.y + m_dropdown_end - 23.f }, color_t(18, 23, 32, data->m_alpha));

			for (size_t i = 0; i < m_items.size(); i++)
			{
				float x = m_box_start.x + 10.f;
				float y = m_end.y + 5.f + i * m_item_height;

				if (y + (m_item_height * 0.5f) > m_end.y + m_dropdown_end - 2.f)
					continue;

				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { x, y }, m_items.at(i).m_text, *m_items.at(i).m_setting ? data->m_color : color_t(255, 255, 255, data->m_alpha));
			}
		}
	};

	class c_color_picker : public c_control
	{
		const char* m_text{};
		color_t m_temp_col{};
		color_t m_picker_col{};
		int m_elem_tracker = -1;

		bool m_is_open{};
		bool m_rainbow_mode{};
		bool m_inside_picker_window{};
		bool m_inside_picker{};
		bool m_inside_hue_picker{};
		bool m_inside_alpha_picker{};
		bool m_inside_rainbow_box{};
		int m_draw_tick{};

		float m_picker_hue_val = 0.f;
		float m_picker_val_x = 1.f;
		float m_picker_val_y = 1.f;
		float m_picker_alpha_val = 255.f;

		vec2 m_box_start{};
		vec2 m_box_end{};
		vec2 m_box_bounds{ 20, 8 };

		vec2 m_picker_window_start{};
		vec2 m_picker_window_end{};
		vec2 m_picker_window_bounds{ 150, 150 };

		vec2 m_picker_start{};
		vec2 m_picker_end{};
		vec2 m_picker_bounds{};

		vec2 m_hue_picker_start{};
		vec2 m_hue_picker_end{};
		vec2 m_hue_picker_bounds{};

		vec2 m_alpha_picker_start{};
		vec2 m_alpha_picker_end{};
		vec2 m_alpha_picker_bounds{};

		vec2 m_rainbow_box_start{};
		vec2 m_rainbow_box_bounds{};
		vec2 m_rainbow_box_end{};
	public:
		void draw(c_window_data* data)
		{
			color_t text_color(255, 255, 255, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 21.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 20.f, m_start.y - 3.f }, m_text, text_color);
			}

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_box_start.y, m_box_bounds.x, m_box_bounds.y }, { m_temp_col.r(), m_temp_col.g(), m_temp_col.b(), data->m_alpha });
		}

		void handle(c_window_data* data, const char* text, uint8_t* r, uint8_t* g, uint8_t* b, uint8_t* a)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = text;
			m_start = vec2(data->m_x, data->m_y);
			m_draw_tick = data->m_draw_counter;

			m_box_start = vec2(data->m_x + 150.f, data->m_y);
			m_box_end = m_box_start + m_box_bounds;

			m_picker_window_start = vec2(m_box_start.x, m_box_start.y + 10);
			m_picker_window_end = m_picker_window_start + m_picker_window_bounds;

			m_picker_start = vec2(m_picker_window_start.x + 3.f, m_picker_window_start.y + 3.f);
			m_picker_bounds = vec2(m_picker_window_bounds.x - 25.f, m_picker_window_bounds.y - 25.f);
			m_picker_end = m_picker_start + m_picker_bounds;

			m_hue_picker_start = vec2(m_picker_end.x + 6.f, m_picker_start.y);
			m_hue_picker_bounds = vec2(10.f, m_picker_bounds.y);
			m_hue_picker_end = m_hue_picker_start + m_hue_picker_bounds;

			m_alpha_picker_start = vec2(m_picker_start.x, m_picker_end.y + 6.f);
			m_alpha_picker_bounds = vec2(m_picker_bounds.x, 10.f);
			m_alpha_picker_end = m_alpha_picker_start + m_alpha_picker_bounds;

			m_rainbow_box_start = vec2(m_alpha_picker_end.x + 5.f, m_alpha_picker_start.y);
			m_rainbow_box_bounds = vec2(10.f, 10.f);
			m_rainbow_box_end = m_rainbow_box_start + m_rainbow_box_bounds;

			m_temp_col = { *r, *g, *b, *a };
			if (data->m_first_draw)
			{
				m_picker_col = { *r, *g, *b, *a };
				m_picker_hue_val = m_picker_col.to_hue();
				m_picker_alpha_val = *a;
			}

			if (m_rainbow_mode)
			{
				ctx.m_color_manager.add_color(c_color_manager::sinebow, &m_rainbow_mode, { r, g, b });

				m_temp_col.a((int)m_picker_alpha_val);

				*r = m_temp_col.r();
				*g = m_temp_col.g();
				*b = m_temp_col.b();
				*a = m_temp_col.a();
			}

			// setup coord for next item
			data->m_y += 15.f;

			m_is_inside = m_cursor_x > m_box_start.x&& m_cursor_x < m_box_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_box_end.y;
			m_inside_picker_window = m_cursor_x > m_picker_window_start.x&& m_cursor_x < m_picker_window_end.x && m_cursor_y > m_picker_window_start.y&& m_cursor_y < m_picker_window_end.y;
			m_inside_picker = m_cursor_x > m_picker_start.x&& m_cursor_x < m_picker_end.x && m_cursor_y > m_picker_start.y&& m_cursor_y < m_picker_end.y;
			m_inside_hue_picker = m_cursor_x > m_hue_picker_start.x&& m_cursor_x < m_hue_picker_end.x && m_cursor_y > m_hue_picker_start.y&& m_cursor_y < m_hue_picker_end.y;
			m_inside_alpha_picker = m_cursor_x > m_alpha_picker_start.x&& m_cursor_x < m_alpha_picker_end.x && m_cursor_y > m_alpha_picker_start.y&& m_cursor_y < m_alpha_picker_end.y;
			m_inside_rainbow_box = m_cursor_x > m_rainbow_box_start.x&& m_cursor_x < m_rainbow_box_end.x && m_cursor_y > m_rainbow_box_start.y&& m_cursor_y < m_rainbow_box_end.y;

			if (m_is_inside && data->m_first_click && !data->m_ignore)
			{
				m_is_open = true;
				data->m_ignore = true;
			}

			if (!m_is_inside && !m_inside_picker_window && data->m_first_click && m_is_open)
			{
				m_is_open = false;
				data->m_ignore = false;
			}

			if (m_is_open && m_inside_picker_window)
				data->m_ignore = true;

			if (m_is_open && data->m_left_click && m_inside_picker_window)
			{
				if (m_inside_picker && (m_elem_tracker == -1 || m_elem_tracker == 0) && !m_rainbow_mode)
				{
					if (data->m_first_click)
						m_elem_tracker = 0;

					m_picker_val_x = std::clamp((m_cursor_x - m_picker_start.x) / (m_picker_bounds.x - 1.f), 0.f, 1.f);
					m_picker_val_y = 1.f - std::clamp((m_cursor_y - m_picker_start.y) / (m_picker_bounds.y - 1.f), 0.f, 1.f);
				}

				if (m_inside_hue_picker && (m_elem_tracker == -1 || m_elem_tracker == 1) && !m_rainbow_mode)
				{
					if (data->m_first_click)
						m_elem_tracker = 1;

					m_picker_hue_val = std::clamp((m_cursor_y - m_hue_picker_start.y) / (m_hue_picker_bounds.y - 1.f), 0.f, 1.f);
					m_picker_col.from_hsv(m_picker_hue_val, 1.f, 1.f);
				}

				if (m_inside_alpha_picker && (m_elem_tracker == -1 || m_elem_tracker == 2))
				{
					if (data->m_first_click)
						m_elem_tracker = 2;

					m_picker_alpha_val = std::clamp(((m_cursor_x - m_alpha_picker_start.x) / (m_alpha_picker_bounds.x)) * 255.f, 0.f, 255.f);
				}

				if (m_inside_rainbow_box && (m_elem_tracker == -1 || m_elem_tracker == 3))
				{
					if (data->m_first_click)
					{
						m_elem_tracker = 3;
						m_rainbow_mode = !m_rainbow_mode;
					}
				}

				m_temp_col.from_hsv(m_picker_hue_val, m_picker_val_x, m_picker_val_y);
				m_temp_col.a((int)m_picker_alpha_val);

				*r = m_temp_col.r();
				*g = m_temp_col.g();
				*b = m_temp_col.b();
				*a = m_temp_col.a();

			}
			else
			{
				m_elem_tracker = -1;
				m_picker_col.from_hsv(m_picker_hue_val, 1.f, 1.f);
			}

			draw(data);
		}

		void picker(c_window_data* data)
		{
			if (!m_is_open)
				return;

			if (data->m_alpha < 255)
			{
				m_is_open = false;
				return;
			}

			if (m_draw_tick != data->m_draw_counter)
				return;

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_picker_window_start.x - 1.f, m_picker_window_start.y - 1.f, m_picker_window_bounds.x + 2.f, m_picker_window_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_picker_window_start.x, m_picker_window_start.y, m_picker_window_bounds.x, m_picker_window_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			color_t gradient_color{};
			gradient_color.from_hsv(m_picker_hue_val, 1.f, 1.f);

			ctx.m_renderer->draw_gradient_rect(ctx.m_renderer->m_menu_element_list, { m_picker_start.x, m_picker_start.y, m_picker_bounds.x, m_picker_bounds.y }, color_t(255, 255, 255, data->m_alpha), color_t(gradient_color.r(), gradient_color.g(), gradient_color.b(), data->m_alpha), color_t(255, 255, 255, data->m_alpha), color_t(gradient_color.r(), gradient_color.g(), gradient_color.b(), data->m_alpha));
			ctx.m_renderer->draw_gradient_rect(ctx.m_renderer->m_menu_element_list, { m_picker_start.x, m_picker_start.y, m_picker_bounds.x, m_picker_bounds.y }, color_t(0, 0, 0, 0), color_t(0, 0, 0, 0), color_t(0, 0, 0, data->m_alpha), color_t(0, 0, 0, data->m_alpha));

			ctx.m_renderer->draw_rect(ctx.m_renderer->m_menu_element_list, { m_picker_start.x + (m_picker_bounds.x * (round(100.f * m_picker_val_x) / 100.f)) - 2.5f, m_picker_start.y + (m_picker_bounds.y * (round(100.f * (1.f - m_picker_val_y)) / 100.f)) - 2.5f, 5.f, 5.f }, color_t(0, 0, 0, data->m_alpha));

			const color_t hue_col[7] =
			{
				{ 255, 0, 0  , data->m_alpha },
				{ 255, 255, 0, data->m_alpha },
				{ 0, 255, 0  , data->m_alpha },
				{ 0, 255, 255, data->m_alpha },
				{ 0, 0, 255  , data->m_alpha },
				{ 255, 0, 255, data->m_alpha },
				{ 255, 0, 0  , data->m_alpha }
			};

			for (auto i = 0; i < 6; ++i)
			{
				const vec4 v(m_hue_picker_start.x, m_hue_picker_start.y + ((i * m_hue_picker_bounds.y) / 6.f), m_hue_picker_bounds.x, (m_hue_picker_bounds.y / 6.f));
				ctx.m_renderer->draw_gradient_rect(ctx.m_renderer->m_menu_element_list, v, hue_col[i], hue_col[i], hue_col[i + 1], hue_col[i + 1]);
			}
			ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { m_hue_picker_start.x - 2.f, m_hue_picker_start.y + (m_hue_picker_bounds.y * (round(100.f * m_picker_hue_val) / 100.f)) }, { m_hue_picker_end.x + 2.f, m_hue_picker_start.y + (m_hue_picker_bounds.y * (round(100.f * m_picker_hue_val) / 100.f)) }, color_t(0, 0, 0, data->m_alpha));

			ctx.m_renderer->draw_gradient_rect(ctx.m_renderer->m_menu_element_list, { m_alpha_picker_start.x, m_alpha_picker_start.y, m_alpha_picker_bounds.x, m_alpha_picker_bounds.y }, color_t(0, 0, 0, data->m_alpha), color_t(255, 255, 255, data->m_alpha), color_t(0, 0, 0, data->m_alpha), color_t(255, 255, 255, data->m_alpha));
			ctx.m_renderer->draw_line(ctx.m_renderer->m_menu_element_list, { m_alpha_picker_start.x + (m_alpha_picker_bounds.x * (round(m_picker_alpha_val) / 255.f)), m_alpha_picker_start.y - 2.f }, { m_alpha_picker_start.x + (m_alpha_picker_bounds.x * (round(m_picker_alpha_val) / 255.f)), m_alpha_picker_end.y + 2.f }, color_t(0, 0, 0, data->m_alpha));

			ctx.m_renderer->draw_filled_rect(ctx.m_renderer->m_menu_element_list, { m_rainbow_box_start.x, m_rainbow_box_start.y, m_rainbow_box_bounds.x, m_rainbow_box_bounds.y }, m_temp_col);
		}
	};

	class c_text_input : public c_control
	{
		const char* m_text{};
		char* m_setting{};

		vec2 m_box_start;

		float m_draw_time{};
	public:
		bool m_is_waiting{};

		void handle(c_window_data* data, const char* text, char* setting, int buffer_size = 32, const bool& numbers_only = false)
		{
			g_input.get_cursor_pos(m_cursor_x, m_cursor_y);

			m_text = strlen(text) > 1 ? text : nullptr;
			m_setting = setting;

			m_start = vec2(data->m_x + 20.f, data->m_y);
			m_box_start = vec2(m_start.x, m_start.y);

			data->m_y += 30.f;

			if (m_text)
			{
				m_box_start.y += 15.f;
				data->m_y += 20.f;
			}

			m_bounds = vec2(150, 20);

			m_end = m_box_start + m_bounds;

			m_is_inside = m_cursor_x > m_box_start.x&& m_cursor_x < m_end.x && m_cursor_y > m_box_start.y&& m_cursor_y < m_end.y;

			if (data->m_first_click)
			{
				if (!data->m_ignore && m_is_inside)
				{
					m_is_waiting = true;
					data->m_ignore = true;
				}
				else
				{
					m_is_waiting = false;
				}
			}

			if (data->m_right_click && m_is_inside)
				memset(m_setting, 0, sizeof(m_setting));

			if (m_is_waiting)
				ctx.m_block_keyinput = true;

			if (!numbers_only || isdigit(data->m_keyboard_input))
			{
				if (m_is_waiting && data->m_keyboard_input > 0)
				{
					size_t length = strlen(m_setting);

					if (data->m_keyboard_input == 0x8) //backspace
					{
						if (length > 0)
							m_setting[length - 1] = 0;
					}
					else if (length < (buffer_size - 1))
					{
						if (util::is_valid_text(data->m_keyboard_input))
						{
							m_setting[length] = data->m_keyboard_input;
							m_setting[length + 1] = 0;
						}
					}
				}
			}

			draw(data);
		}

		void draw(c_window_data* data)
		{
			color_t text_color(255, 255, 255, data->m_alpha);
			color_t text_shadow(0, 0, 0, data->m_alpha);

			if (m_text)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x + 1.f, m_start.y - 2.f }, m_text, text_shadow);
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_start.x, m_start.y - 3.f }, m_text, text_color);
			}

			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x - 1.f, m_box_start.y - 1.f, m_bounds.x + 2.f, m_bounds.y + 2.f }, color_t(49, 67, 93, data->m_alpha));
			ctx.m_renderer->draw_filled_rounded_rect(ctx.m_renderer->m_menu_element_list, { m_box_start.x, m_box_start.y, m_bounds.x, m_bounds.y }, color_t(18, 23, 32, data->m_alpha));

			if (strlen(m_setting) > 0)
			{
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_end.x - 12.0f, m_box_start.y + 3.0f }, "x", color_t(255, 255, 255, data->m_alpha));

				const bool inside_x = m_cursor_x > m_end.x - 14.0f && m_cursor_x < m_end.x - 4.0f && m_cursor_y > m_box_start.y && m_cursor_y < m_end.y;

				if (inside_x && data->m_left_click)
					memset(m_setting, 0, sizeof(m_setting));
			}

			std::string draw_text(m_setting);
			float setting_width = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), draw_text).x;

			if (m_is_waiting)
			{
				while (setting_width > (m_bounds.x - 22.f))
				{
					draw_text.erase(0, 1);
					setting_width = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), draw_text).x;
				}
			}
			else if (strlen(m_setting) < 1)
				ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.f, m_box_start.y + 3.f }, xors("..."), color_t(203, 203, 203, data->m_alpha));

			if (!m_is_waiting)
			{
				while (setting_width > (m_bounds.x - 22.f))
				{
					draw_text.pop_back();
					setting_width = ctx.m_renderer->get_text_extent(ctx.m_renderer->get_font(font_fury_normal_serif), draw_text).x;
				}
			}

			ctx.m_renderer->string(ctx.m_renderer->m_menu_element_list, ctx.m_renderer->get_font(font_fury_normal_serif), { m_box_start.x + 10.f, m_box_start.y + 3.f }, draw_text, color_t(255, 255, 255, data->m_alpha));
		}
	};
}