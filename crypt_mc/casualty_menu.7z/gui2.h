#pragma once

#include <vector>
#include <string>
#include <iterator>
#include "renderer.h"

class c_fury_gui
{
	enum tabs_t
	{
		TABS_LEGIT,
		TABS_RAGE,
		TABS_VISUALS,
		TABS_WORLD,
		TABS_MISC,
		TABS_CONFIG
	};

	std::vector<std::string> m_tabs =
	{
		xors("LEGIT"),
		xors("RAGE"),
		xors("VISUALS"),
		xors("WORLD"),
		xors("MISC"),
		xors("CONFIG")
	};

	void tab_legit();
	void tab_rage();
	void tab_visuals();
	void tab_world();
	void tab_misc();
	void tab_config();

public:
	void background();
	void draw();
};

extern c_fury_gui fury_gui;