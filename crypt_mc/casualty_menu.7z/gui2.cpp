﻿#include "renderer.h"
#include "context.h"

#include "gui2.h"

#include <stdio.h>
#include <algorithm>

#include "menu2.h"
#include <gl\GL.h>

// symbols often used that are hard to get
// �

c_fury_gui gui;

// wont work cuz menu handles loading/ saving, meaning pos gets set before we can update it
UI::c_window fury_menu(&ctx.m_settings.gui_menu_pos);

void c_fury_gui::background()
{
}

void c_fury_gui::tab_legit()
{
	static UI::c_groupbox left_groupbox;
	static UI::c_checkbox left_checkbox;
	static bool left_bool = false;
	static UI::c_slider left_slider;
	static int left_int = 1;
	static UI::c_float_slider left_float_slider;
	static float left_float = 1.f;

	static UI::c_groupbox left_groupbox2;
	static UI::c_button left_button;
	static UI::c_key_bind left_keybind;
	static keysetting_t left_keysetting{};

	static UI::c_groupbox center_groupbox;
	static UI::c_dropdown center_dropdown;
	static int center_selector = 1;
	static UI::c_multi_dropdown center_multidropdown;
	static bool center_option1 = false;
	static bool center_option2 = false;
	static bool center_option3 = false;

	static UI::c_groupbox right_groupbox;
	static UI::c_text_input right_textinput;
	static char right_buffer[32]{};
	static UI::c_color_picker right_colorpicker;
	static uint8_t right_r = 0, right_g = 0, right_b = 0, right_a = 0;

	fury_menu.column_left();
	{
		left_groupbox.start(fury_menu.data(), xors("left groupbox"));
		{
			left_checkbox.handle(fury_menu.data(), xors("left checkbox"), &left_bool);
			left_slider.handle(fury_menu.data(), xors("left slider"), &left_int, 0, 100, 1, xors(" suffix"));
			left_float_slider.handle(fury_menu.data(), xors("left float_slider"), &left_float, 0.f, 100.f);
		}
		left_groupbox.end(fury_menu.data());

		left_groupbox2.start(fury_menu.data(), xors("left groupbox 2"));
		{
			left_button.handle(fury_menu.data(), xors("left button"), []() {
					return;
				});

			left_keybind.handle(fury_menu.data(), xors("left keybind"), &left_keysetting, kt_all);
		}
		left_groupbox2.end(fury_menu.data());
		left_keybind.dropdown(fury_menu.data());
	}

	fury_menu.column_center();
	{
		center_groupbox.start(fury_menu.data(), xors("center groupbox"));
		{
			center_dropdown.handle(fury_menu.data(), xors("center dropdown"), { xors("option #1"), xors("option #2"), xors("option #3") }, &center_selector);
			center_multidropdown.handle(fury_menu.data(), xors("center multidropdown"), {
					{ &center_option1, xors("option #1") },
					{ &center_option2, xors("option #2") },
					{ &center_option3, xors("option #3") }
				});
		}
		center_groupbox.end(fury_menu.data());
		center_dropdown.dropdown(fury_menu.data());
		center_multidropdown.dropdown(fury_menu.data());
	}

	fury_menu.column_right();
	{
		right_groupbox.start(fury_menu.data(), xors("right groupbox"));
		{
			right_textinput.handle(fury_menu.data(), xors("right text input"), right_buffer);
			right_colorpicker.handle(fury_menu.data(), xors("right color picker"), &right_r, &right_g, &right_b, &right_a);
		}
		right_groupbox.end(fury_menu.data());
		right_colorpicker.picker(fury_menu.data());
	}
}

void c_fury_gui::tab_rage()
{
}

void c_fury_gui::tab_visuals()
{
}

void c_fury_gui::tab_world()
{
}

void c_fury_gui::tab_misc()
{
}

void c_fury_gui::tab_config()
{
}

void c_fury_gui::draw()
{
	if (!fury_menu.handle(m_tabs, color_t(ctx.m_settings.gui_accent_color().r(), ctx.m_settings.gui_accent_color().g(), ctx.m_settings.gui_accent_color().b())))
		return;

	switch (fury_menu.m_current_tab)
	{
		case TABS_LEGIT:
		{
			tab_legit();
			break;
		}

		case TABS_RAGE:
		{
			tab_rage();
			break;
		}

		case TABS_VISUALS:
		{
			tab_visuals();
			break;
		}

		case TABS_WORLD:
		{
			tab_world();
			break;
		}

		case TABS_MISC:
		{
			tab_misc();
			break;
		}

		case TABS_CONFIG:
		{
			tab_config();
			break;
		}

		default:
			break;
	}
}
